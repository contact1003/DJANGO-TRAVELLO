from django.shortcuts import render
from .models import destinations


# Create your views here.

def index(request):

    dest1 =destinations()
    dest1.name="Patna"
    dest1.price=500
    dest1.desc="Land of Bodh gaya"
    dest1.img="destination_1.jpg"

    dest2 =destinations()
    dest2.name="Delhi"
    dest2.price=1000
    dest2.desc="Polluted city except South Delhi"
    dest2.img="destination_2.jpg"

    dest3 =destinations()
    dest3.name="Mumbai"
    dest3.price=1500
    dest3.desc="Expensive Place"
    dest3.img="destination_3.jpg"
    
    dests=[dest1,dest2,dest3]

    return render(request,"index.html",{"dests":dests})